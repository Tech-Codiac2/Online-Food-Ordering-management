<?php
include('adlog.php'); // Includes Login Script

?>
<?php
include('admh.php'); // Includes Login Script

?>
<?php
include('db_conn.php');
if(!isset($_SESSION['login_user'])){
//header("location: index.php"); // Redirecting To Home Page
}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
<title>welcome <?php echo $login_session ;?></title>

</head>
<body>
	<h2 style="text-align:center">welcome Admin</h2>


</div>
</body>
</html>
<?php
$connection = mysqli_connect("localhost", "root", "", 
                                                 "proj");
    
    if (mysqli_connect_errno())
    {
        echo "Database connection failed.";
    }
      
    
    $query = "SELECT id  FROM register";

      
    
    $result = mysqli_query($connection, $query);
      
    if ($result)
    {

        
        $row = mysqli_num_rows($result);
          
           if ($row)
              {
                 //printf("Number of users in the table : " . $row);
              }
             // echo $row;
       
        mysqli_free_result($result);
    }
  
    // Connection close 
    mysqli_close($connn);
?>
<?php
$connectionn = mysqli_connect("localhost", "root", "", 
                                                 "proj");
    
    if (mysqli_connect_errno())
    {
        echo "Database connection failed.";
    }
      
    
    $queryy = "SELECT sum( total ) FROM 'orders";
    
      
    
    $resultt = mysqli_query($connection, $query);
      
    if ($resultt)
    {

        
        $roww = mysqli_num_rows($t);
          
           if ($roww)
              {
                 printf("Number of users in the table : " . $roww);
              }
             // echo $row;
       
        mysqli_free_result($result);
    }
  
    // Connection close 
    mysqli_close($connn);
?>
	<h3 style="text-align:center">your total number of users= <?php echo $row ;?></h1>
		


</div>
</body>
</html>