

<?php
$var_value = $_GET['varname'];
include('db_conn.php');
include('login.php');
 
if(!isset($_SESSION['login_user'])){
 
//header("location: index.php"); // Redirecting To Home Page
}
?>

<!DOCTYPE html>
<html>
<style type="text/css">
  body{
    background-color: #ff4f58ff;
  font-family: "Comic Sans MS", cursive, sans-serif;

  }
  form {
  
  background-color: #ff4f58ff;
  font-family: "Comic Sans MS", cursive, sans-serif;

  
}
</style>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<title>welcome <?php echo $login_session ;?></title>

</head>

<body>
  <h2 style="text-align:center">welcome <?php echo $_SESSION['login_user'] ; ?> </h2>


</div>
</body>
</html>
<?php

$var_value=intval($_GET['varname']);
$connection = mysqli_connect("localhost", "root", "", 
                                                 "proj");
    
    if (mysqli_connect_errno())
    {
        echo "Database connection failed.";
    }
     
      
      $amall= $_SESSION['login_user'] ;


    $query = "SELECT * FROM register WHERE user='$amall' ";

      
    
    $result = mysqli_query($connection, $query);
      
    
        
        while($row =mysqli_fetch_array($result)) {

    ?>
     <form action="" method="POST">
  

        <div   class="col-md-3 mt-3   ">


      <div class="card">
        <div class="card-body">

          <div class="ddd">



      

      
      <h2 class="card-title">Your ID :<?php echo $row['id'];?></h2>
          
        <h2 class="card-title">Your Regisered Name :<?php echo $row['user'];?></h2>
        
        
          
          <h2 class="card-title">Your Password :<?php echo $row['password'];?></h2>
          <h2 class="card-title"> Your Phone NO :<?php echo $row['phoneCode'];?></h2>
         
           <div class="ban-bottom">
        <div class="bnr-right">
        
        
      </div>
      </div>
          

          

        

      </div>
    </div>
  </div>

</div>

<?php  
    
    # code...
  
}

 ?>
 </form>

