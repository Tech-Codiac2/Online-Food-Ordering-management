<?php
require('admh.php')
?>
<?php
include("db_conn.php");
error_reporting(0);
$query="SELECT * FROM food ";
$data=mysqli_query($connn,$query);
$total=mysqli_num_rows($data);
$result=mysqli_fetch_assoc($data);

 
 if($total != 0)
 {

 ?>
 <style type="text/css">
   form{
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
    table{
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
    tr,td,th{
      font-family: "Comic Sans MS", cursive, sans-serif;

    }
 </style>
<form action="updatep.php" method="POST">
 <table>
 	<h1>list of food</h1>
 
<style type="text/css">
	table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

 td,  th {
  border: 1px solid #ddd;
  padding: 8px;
}

 tr:nth-child(even){background-color: #ff4f58ff;}

 tr:hover {background-color: #ddd;}

 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000000;
  color: white;
}
</style>
 	

 	<tr>
 		<th>id</th>
 		<th>pic</th>
 		<th>name</th>
 		<th>type</th>
 		<th>price</th>
 		<th>details</th>
 		<th colspan="2"> operations</th>
 	</tr>
 
 <?php 
 $idd=$_POST['result["id"]'];
 while ($result=mysqli_fetch_assoc($data))
  {
 	echo "<tr>
 		<td>".$result['id']."</td>
 		<td><a href='$result[img]'><img src='".$result['img']."' height='100' width='100'/><a/></td>
 		<td>".$result['name']."</td>
 		<td>".$result['type']."</td>


 	  <td>".$result['price']."</td>
 		<td>".$result['details']."</td>
 			<td> <a href='updatep.php?icc=$result[id]&iii=$result[name]&ty=$result[type]&iiii=$result[price]&det=$result[details]'>update</a></td>
 		<td> <a href='deletep.php?icc=$result[id]&iii=$result[name]&ty=$result[type]&iiii=$result[price]&det=$result[details]'>delete</a></td>
 		
 	</tr>";
}
}
 else
 {
 	echo " lol";
 }
  ?>
</table>
</form>
 