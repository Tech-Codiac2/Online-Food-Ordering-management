<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	</head>

	

	<style type="text/css">
		
		.section {
			background-image:url(1.jpg);
			background-size: 1000px;
		
		}

		

	</style>
<body >
	<div class="topbar">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="pull-left hidden-xs">food ordering & management system </h1>
        
      </div>
    </div>
  </div>
</div>
	<section class="section">
	<header>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <button
        class="navbar-toggler"
        type="button"
        data-mdb-toggle="collapse"
        data-mdb-target="#navbarExample01"
        aria-controls="navbarExample01"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarExample01">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item active">
            <a class="nav-link" aria-current="page" href="index.php">Home</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="mainpg.php">Pricing</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
            <li class="nav-item">
            <a class="nav-link" href="adminlog.php">admin</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Navbar -->

  <!-- Background image -->
  <div
    class="p-5 text-center bg-image"
    style="
      background-image: url('1.jpg');
      height: 500px;
    "
  >
    <div class="mask" style="background-color: rgba(0, 0, 0, 0.6)">
      <div class="d-flex justify-content-center align-items-center h-100">
        <div class="text-white">
          <h1 class="mb-3">welcome</h1>
          <h4 class="mb-3">we serve the best food</h4>
          <a class="btn btn-outline-light btn-lg" href="mainpg.php" role="button"
            >order now</a
          >
        </div>
      </div>
    </div>
  </div>
  <!-- Background image -->
</header>
		
	</section>
	<section class="feature_wrap padding-half" id="specialities">
  <div class="container">
    <div class="row">
     <div class="col-md-12 text-center">
        <h2 class="heading ">Our &nbsp; Specialities</h2>
        <hr class="heading_space">
      </div>
    </div>
    <div class="row">
      <div class="col-md-3 col-sm-6 feature text-center">
      <i class="fa fa-cutlery fa-4x" aria-hidden="true"></i>
        <h3><a href="din&des.php">Dinner &amp; Dessert</a></h3>
        <p> </p>
      </div>
      <div class="col-md-3 col-sm-6 feature text-center">
        <i class="fa fa-coffee fa-4x" aria-hidden="true"></i>
        <h3><a href="breakfast.php">Breakfast</a></h3>
        <p> </p>
      </div>
      <div class="col-md-3 col-sm-6 feature text-center">
       <i class="fa fa-glass fa-4x" aria-hidden="true"></i>
        <h3><a href="shakes.php">Ice Shakes</a></h3>
        <p> </p>
      </div>
      <div class="col-md-3 col-sm-6 feature text-center">
        <i class="fa fa-beer fa-4x" aria-hidden="true"></i>
        <h3><a href="drinks.php">Beverges</a></h3>
        <p></p>
      </div>
    </div>
    
  </div>
</section>



	
 

   

</body>


</html>