<?php
include("db_conn.php");
error_reporting(0);

?>
<!DOCTYPE html>
<html>
<head>
	<title> update</title>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<style type="text/css">


		body{
			font-family: 'Artifika';font-size: 22px;
			 background-image:url(f/iii.jpg);
   background-size: 1400px;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
		
		}
		form{font-family: 'Artifika';font-size: 22px;}
		h1{font-family: 'Artifika';font-size: 22px;}
	</style>
<div class="container-fluid">
 <div class="row justify-content-center">
  <div class="form-group col-md-4 col-md-offset-5 align-center  "color: #fff;>
  	<dib color: #fff;>
  

<body >
	<?php echo  $ic;  ?>
	<h1>update products</h1>
	 <div class="form-floating mb-3">
<form  action ="" method="GET"  >

id <input type="text" class="form-control"name="id" value="<?php echo $_GET['icc'];?>"> <br>
name <input type="text" class="form-control"name="namee" value="<?php echo $_GET['iii'];?>" .=""><br>

price <input type="text"class="form-control" name="price" value="<?php echo $_GET['iiii'];?>" .=""><br>
type <input type="text"class="form-control" name="type" value="<?php echo $_GET['ty'];?>" .=""><br>
details <input type="text"class="form-control" name="details" value="<?php echo $_GET['det'];?>" .=""><br>

<input type="submit"  name="submit" value="Submit" ><br>
</div>
</head>
</form>
<?php 


if ($_GET['submit']) {
	

$id= $_GET['id'];
$name= $_GET['namee'];
$type= $_GET['type'];

$price= $_GET['price'];

$details= $_GET['details'];
$filenm=$_FILES["uploadfile"]["name"]; //name of the file
$temp= $_FILES["uploadfile"]["tmp_name"];// giving tempname to store 
$folder="imagee/".$filenm; //storing the image
echo $folder;
move_uploaded_file($temp, $folder);


//if ($id!=''&& $name!=''&& $type!=''&&$price!=''&&$details!='' &&$filenm!='') 

	$queryy ="UPDATE food SET name='$name',price='$price',type='$type',details='$details' WHERE id='$id'";
$data= mysqli_query($connn , $queryy);

 

if ($data) {
	header('Refresh: 1; url=viewp.php');
}
}
else{
	echo "all fiels are  required.";

}

	

//echo "<img src='$folder' height='100' width='100' />";

?>



</body>
</html>