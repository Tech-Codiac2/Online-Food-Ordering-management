


<!DOCTYPE HTML>
<html>
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <title>Register Form</title>
  <style >
  
  body {
   background-image:url(f/ll.jfif);
   background-size: 1050px;

     
  
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  
  
}
form {
  width: 500px;
  border: 2px solid #ccc;
  padding: 30px;
  background-color: #FFFFFF;
  border-radius: 15px;
}

.button2 {background-color: #008CBA;}
</style>

</head>

<body>
 <form action="insert.php" method="POST">
  <h2>register Form</h2>
  <table>
   <tr>
    <td>Name :</td>
    <td><input  class="form-control"type="text" name="username" required></td>
   </tr>
   <tr>
    <td>Password :</td>
    <td><input class="form-control" type="password" name="password" required></td>
   </tr>
   <tr>
    <td>Address :</td>
    <td>
     <input  class="form-control"type="text" name="address" required>
    
    </td>
   </tr>
   <tr>
    <td>Email :</td>
    <td><input class="form-control"type="email" name="email" required></td>
   </tr> 
   
    <td>Phone no :</td>
    <td>
     <select class="form-control" name="phoneCode" required>
      <option  class="form-control"selected hidden value="">Select Code</option>
      <option class="form-control" value="91">91</option>
      <option  class="form-control"value="92">92</option>
      <option class="form-control" value="93">93</option>
      <option  class="form-control"value="94">94</option>
      <option  class="form-control"value="95">95</option>
      <option class="form-control" value="96">96</option>
     </select>
     <input  class="form-control"type="phone" name="phone" required>
    </td>
   </tr>
   <tr>
    <td><input  class="button2"type="submit" value="Submit"></td>
   </tr>
  </table>
 </form>
</body>
</html>