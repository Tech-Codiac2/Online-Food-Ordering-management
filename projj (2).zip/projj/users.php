<?php
include('adlog.php'); // Includes Login Script

?>
<?php
include('admh.php'); // Includes Login Script

?>

<?php
include("db_conn.php");
error_reporting(0);
$query="SELECT id ,user,address,phoneCode,phone FROM register ";
$data=mysqli_query($connn,$query);
$total=mysqli_num_rows($data);
$result=mysqli_fetch_assoc($data);
 
 if($total != 0)
 {

 ?>
 <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<style type="text/css">
	h1{
  
      font-family: "Comic Sans MS", cursive, sans-serif;
  }
  table {
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

 td,  th {

  border: 1px solid #ddd;
  padding: 8px;
}

 tr:nth-child(even){background-color: #f2f2f2;}

 tr:hover {background-color: #ddd;}

 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000000;
  color: white;
}
</style>

 <table class="table table-hover">
 	<h1>registered users</h1>
 	

 	<tr>
 		<th>id</th>
 		<th>user</th>
 		<th>address</th>
 		<th>phoneCode</th>
    <th>phone number</th>
 		<th colspan="2"> operations</th>
 	</tr>
 
 <?php 
 while ($result=mysqli_fetch_assoc($data))
  {
 	echo "<tr>
 		<td>".$result['id']."</td>
 		<td>".$result['user']."</td>
 		
 		<td>".$result['address']."</td>
 		<td>".$result['phoneCode']."</td>
 		<td>".$result['phone']."</td>
 		<td> <a href='updatep.php?ii=$result[id]&iii=$result[name]&iiii=$result[price]'>edit</a></td>
 		<td> <a href='deletep.php?ii=$result[id]&iii=$result[name]&iiii=$result[price]'>delete</a></td>
 		
 	</tr>";
}
}
 else
 {
 	echo " lol";
 }
  ?>
</table>