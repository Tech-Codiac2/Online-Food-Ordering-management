<?php
error_reporting(0);

$sname= "localhost";
$unmae= "root";
$password = "";

$db_name = "proj";

$connn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$connn) {
	echo "Connection failed!";
}






?>




<?php
// mysqli_connect() function opens a new connection to the MySQL server.
$conn = mysqli_connect("localhost", "root", "", "proj");
session_start();// Starting Session
// Storing Session
$user_check = $_SESSION['login_user'];
// SQL Query To Fetch Complete Information Of User
$query = "SELECT user ,id from register where user = '$user_check'";
$ses_sql = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($ses_sql);
$login_session = $row['user'];
$login_id = $row['id'];

?>