<?php
include('adlog.php'); // Includes Login Script


//header("location: profile.php"); // Redirecting To Profile Page

?>













<?php
//include('login.php'); // Includes Login Script

if(isset($_SESSION['ad_user'])){
  error_reporting(0);

  


//header("location: profile.php"); // Redirecting To Profile Page
}
?>


<!DOCTYPE html>


<html>
<head>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  
	<title>
    

		
	</title>
</head>
<style >
  
</style>
<body>

<?php if($_SESSION['ad_user'])
{?>
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="top-header">
  <div class="container">
    <a class="navbar-brand" href="#">welcome admin </a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
       <li class="nav-item active">
      <li class="nav-item active"><a href="index.html"></a></li>
      <li class="prnt"><a class="nav-link" href="profile.php"> profile</a></li>
        <li class="prnt"><a class="nav-link" href="viewp.php"> food</a></li>
                <li class="prnt"><a class="nav-link" href="insertprod.php"> insert food</a></li>


      <li class="prnt"><a  class="nav-link"href="users.php">customers</a></li>
      >
      <li class="prnt"><a class="nav-link" href="orders.php">orders</a></li>
      <li class="prnt"><a class="nav-link" href="logout.php">Sign out</a></li>
    </ul>
    <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
           
    
    <div class="clearfix"></div>
  
  </div><?php } else {?>
    <?php
 header('Location: admin.php'); 
?>
    

     
       
</div>

    <div class="clearfix"></div>
  </div>
</div>
<?php }?>

</nav>
	
