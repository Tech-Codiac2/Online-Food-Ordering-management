<?php
$username = $_POST['username'];
$password = $_POST['password'];
$address = $_POST['address'];
$email = $_POST['email'];

$phoneCode = $_POST['phoneCode'];
$phone = $_POST['phone'];
if (!empty($username) || !empty($password) || !empty($address) || !empty($email) ||  !empty($phoneCode) || !empty($phone)) {
 $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "proj";
    
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     
     $INSERT = "INSERT Into register (user, password, address, email, phoneCode, phone) values(?,  ?,?, ?, ?, ?)";
     //Prepare statement
     
    
      $stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssssii", $username, $password, $address, $email,  $phoneCode, $phone);
      $stmt->execute();
      echo "successfull";


      
     } 
     $stmt->close();
     $conn->close();
    }
 else {
 echo "All field are required";
 die();
}
?>
<!DOCTYPE html>
<html>
<head>
    
</head>
<body>
    <a href="log.php">login</a>

</body>
</html>