
<?php

  ?>





<?php




include("db_conn.php");
error_reporting(0);

?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">


		body {
     background-image:url(f/iii.jpg);
   background-size: 1400px;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
form {
	 width: 500px;
  border: 2px solid #ccc;
  padding: 30px;
  background-color: #FFFFFF;
  border-radius: 15px;
   
}
	</style>
	<title> insert food</title>

</head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
<div class="container-fluid">
 <div class="row justify-content-center">
  <div class="form-group col-md-4 col-md-offset-5 align-center  "color: #fff;>
  	<dib color: #fff;>
  

<body >
	<?php require('admh.php') ?>
	<h1>insert food</h1>
	 <div class="form-floating mb-3">
<form  class="z v1"action ="" method="POST" enctype="multipart/form-data" >

id <input type="text" class="form-control" name="id" value="" required="" placeholder="Enter id"><br>
name <input type="text" class="form-control"name="name" value="" required=""placeholder="Enter name"><br>
type<input type="text" class="form-control"name="type" value="" required=""placeholder="Enter food type"><br>
price <input type="text"class="form-control" name="price" value="" required=""placeholder="Enter price"><br>
details <input type="text"class="form-control" name="details" value="" required=""placeholder="Enter details"><br>
<input  type="file" name="uploadfile" value="" required="">
<input type="submit" name="submit" value="Submit" required=""><br>
</form>
</div>




<?php 


if ($_POST['submit']) {
	

$id= $_POST['id'];
$name= $_POST['name'];
$type= $_POST['type'];

$price= $_POST['price'];

$details= $_POST['details'];
$filenm=$_FILES["uploadfile"]["name"]; //name of the file
$temp= $_FILES["uploadfile"]["tmp_name"];// giving tempname to store 
$folder="imagee/".$filenm; //storing the image
echo $folder;
move_uploaded_file($temp, $folder);


if ($id!=''&& $name!=''&& $type!=''&&$price!=''&&$details!='' &&$filenm!='') 
{
	$queryy ="INSERT INTO food VALUES ('$id','$name','$type','$price','$details','$folder')";
$data= mysqli_query($connn , $queryy);



if ($data) {
	echo "success";
}
}
else{
	echo "all fiels are required";

}
}
	

//echo "<img src='$folder' height='100' width='100' />";

?>
</div>
</body>
</html>