<?php
include('adlog.php'); // Includes Login Script

?>
<?php
include('admh.php'); // Includes Login Script

?>

<?php

include("db_conn.php");
include('login.php');
session_start();
error_reporting(0);
$user= $_SESSION['login_user'];
$query="SELECT * FROM orders INNER JOIN register on orders.name= register.user  ";
$data=mysqli_query($connn,$query);
$total=mysqli_num_rows($data);
$result=mysqli_fetch_assoc($data);

 
 if($total != 0)
 {

 ?>
<form action="" method="POST">
 <table id="table">
 	<h1>customer's orders</h1>
 
<style type="text/css">
  h1{
  
      font-family: "Comic Sans MS", cursive, sans-serif;
  }
	 form{
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
    table{
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
    tr,td,th{
      font-family: "Comic Sans MS", cursive, sans-serif;

    }
    table {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

 td,  th {
  border: 1px solid #ddd;
  padding: 8px;
}

 tr:nth-child(even){background-color: #ff4f58ff;}

 tr:hover {background-color: #ddd;}

 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000000;
  color: white;
}
</style>
 	

 	<tr>
 		<th>id</th>
 		
 		<th>name</th>
     <th>address</th>
      <th>phone</th>
 		<th>order name</th>
    

 		<th>quantity</th>
 		<th> total</th>

 		<th colspan="1"> operations</th>
 	</tr>
 
 <?php 
 $idd=$_POST['result["id"]'];
 while ($result=mysqli_fetch_assoc($data))
  {
 	echo "<tr>
    <td>".$result['id']."</td>
    <td>".$result['name']."</td>
    <td>".$result['address']."</td>
    <td>".$result['phone']."</td>
 		<td>".$result['oname']."</td>
    
      <td>".$result['quantity']."</td>
        <td>".$result['total']."</td>
 		
 		
 			
 		<td> <a href='deletep.php?icc=$result[id]&iii=$result[name]&ty=$result[type]&iiii=$result[price]&det=$result[details]'>delete</a></td>
 		
 	</tr>";
}
}
 else
 {
 	echo " lol";
 }
  ?>
  <span id="val"></span>
</table>
<script>
            
            var table = document.getElementById("table"), sumVal = 0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[6].innerHTML);
            }
            
            document.getElementById("val").innerHTML = "Total Number of sales Done is = " + sumVal;
            console.log(sumVal);
            


            
        </script>
      

</form>
</body>
</html>
 



