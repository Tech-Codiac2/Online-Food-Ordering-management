<?php
session_start(); 
error_reporting(0);
$error = ''; 
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Username or Password is invalid";
}
else{

$username = $_POST['username'];
$password = $_POST['password'];

$conn = mysqli_connect("localhost", "root", "", "proj");

$query = "SELECT adname, adpass from admin where adname=? AND adpass=? LIMIT 1";

$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$stmt->bind_result($username, $password);
$stmt->store_result();
if($stmt->fetch()) 
$_SESSION['ad_user'] = $username; 


header("location: admin.php");
}
mysqli_close($conn); 
}
?>