
<?php
include('login.php'); // Includes Login Script
if(isset($_SESSION['login_user'])){

//header("location: profile.php"); // Redirecting To Profile Page
}
?>













<?php
//include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user1'])){
  error_reporting(0);

  


//header("location: profile.php"); // Redirecting To Profile Page
}
?>


<!DOCTYPE html>


<html>
<head>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  
	<title>
    

		
	</title>
</head>
<style >
  
</style>
<body>
  <?php if($_SESSION['login_user'])
{?>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="top-header">
  <div class="container">
    <a class="navbar-brand" href="#">welcome <?php echo $_SESSION['login_user'] ; ?>  </a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
       <li class="nav-item active">
      <li class="nav-item active"><a href="index.html"></a></li>
      <li class="nav-item active"><a  class="nav-link" href="profile.php">My Profile</a></li>
        <li class="prnt"><a class="nav-link" href="change-password.php">our food</a></li>
      <li class="prnt"><a  class="nav-link"href="tour-history.php">about us</a></li>
      <li class="prnt"><a class="nav-link" href="mainpg.php">order now</a></li>
    </ul>
    <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
           <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button></ul>
    
    <div class="clearfix"></div>
  </div>
  </div><?php } else {?>
<div class="top-header">
  <div class="container">
    <ul class="tp-hd-lft wow fadeInLeft animated" data-wow-delay=".5s">
      <li class="hm"><a href="index.php"><i class="fa fa-home"></i></a></li>
        <li class="hm"><a href="admin/index.php">Admin Login</a></li>
    </ul>
    <ul class="tp-hd-rgt wow fadeInRight animated" data-wow-delay=".5s"> 
      <li class="tol">Toll Number : 123-4568790</li>        
      <li class="sig"><a href="#" data-toggle="modal" data-target="#myModal" >Sign Up</a></li> 
      <li class="sigi"><a href="#" data-toggle="modal" data-target="#myModal4" >/ Sign In</a></li>
        </ul>


    <div class="clearfix"></div>
  </div>
</div>
<?php }?>
</nav>
	
