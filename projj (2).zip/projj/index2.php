<?php
include('login.php'); // Includes Login Script
if(isset($_SESSION['login_user'])){

//header("location: profile.php"); // Redirecting To Profile Page
}
$var_value=$_SESSION['login_user'];
?>













<?php
//include('login.php'); // Includes Login Script

if(isset($_SESSION['login_user1'])){
  error_reporting(0);


  


//header("location: profile.php"); // Redirecting To Profile Page
}
?>


<!DOCTYPE html>


<html>
<head>

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  
	<title>
    

		
	</title>
  <style type="text/css">
    nav{
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
  </style>
</head>
<style >
  
</style>
<body>

  <?php if($_SESSION['login_user'])
{?>
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
<div class="top-header">
  <div class="container">
    <a class="navbar-brand" href="#">welcome <?php echo $_SESSION['login_user'] ; ?>  </a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
       <li class="nav-item active">
      <li class="nav-item active"><a href="index.html"></a></li>
      

      <li class="nav-item active"><a  class="nav-link" href="myprof.php?varname=<?php echo $var_value ?>">My Profile</a></li>
        
      <li class="prnt"><a  class="nav-link"href="about.php">about us</a></li>
      >
      <li class="prnt"><a class="nav-link" href="myorders.php">my orders</a></li>
      <li class="prnt"><a class="nav-link" href="logout.php">Sign out</a></li>
    </ul>
   
    
    <div class="clearfix"></div>
  
  </div><?php } else {?>
    <?php
 header('Location: log.php'); 
?>

     
       
</div>

    <div class="clearfix"></div>
  </div>
</div>
<?php }?>
</nav>
	
