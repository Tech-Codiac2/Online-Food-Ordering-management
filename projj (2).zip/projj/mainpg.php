<?php
require('index2.php')
?>
<?php
include('login.php'); // Includes Login Script
if(isset($_SESSION['login_user'])){

//header("location: profile.php"); // Redirecting To Profile Page
}
?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
	.ddd{
		 background-color: #FFFF ;
		 font-family: "Comic Sans MS", cursive, sans-serif;

	}
	 
	 nav{


	 }

	form {
	
	background-color: #ff4f58ff;
	font-family: "Comic Sans MS", cursive, sans-serif;

	
}

</style>


  <form method="POST">
		
<div class="container py-5">
		<div class="row mt-4">
			


	
<h5>          choose your food</h5>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">

  <a class="navbar-brand" href="mainpg.php">All Foods</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
   
      <nav class="navbar navbar-light bg-light">
      	<ul class="navbar-nav">
      		<li class="nav-item">
      			 <div class="col-md-3 col-sm-6 feature text-center">
      <i class="fa fa-cutlery fa-lg" aria-hidden="true"> <a class="nav-link" href="din&des.php">dinner</a></i>
       
      </li>
     <li class="nav-item">
     	<div class="col-md-3 col-sm-6 feature text-center">
       <i class=" fa fa-beer  fa-lg" aria-hidden="true">   <a class="nav-link" href="drinks.php">drinks& beverages</a></i>
      </li>
      <li class="nav-item">
      	<div class="col-md-3 col-sm-6 feature text-center">
      <i class="fa fa-coffee fa-lg" aria-hidden="true">    <a class="nav-link" href="breakfast.php">breakfast</a></i>
      </li>
      <li class="nav-item">
      	<div class="col-md-3 col-sm-6 feature text-center">
      <i class="fa fa-glass fa-lg" aria-hidden="true">    <a class="nav-link" href="shakes.php">ice shakes</a></i>
      </li>
     

  
    <input class="form-control mr-sm-2" type="search" placeholder="Search" name="food" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" name="search" type="submit">Search</button>
  </form>
</nav>
      </li>
    </ul>
  </div>
</nav>
<section>
<?php
include("db_conn.php");

error_reporting(0);

if(isset($_POST['search']))
{
	$s=$_POST['food'];
	//$s=preg_replace("#[^0-9a-z]#i", "", $s);
	$qq="SELECT * FROM food where name='$s'";
	$qr=mysqli_query($connn,$qq);


	while($row=mysqli_fetch_array($qr))
	 {
	
	
	
 ?>
 <form action="" method="POST">
 	
 	<div   class="col-md-3 mt-3   ">


			<div class="card">
				<div class="card-body">

					<div class="ddd">



			

				<img src=" <?php echo $row['img']; ?>" class="rounded mx-auto d-block"   height="200px" width='200px' alt="img">
					
				<h4 class="card-title"><?php echo $row['name'];?></h4>
				
				
					
					<h3 class="card-title"><?php echo $row['type'];?></h3>
					<h6 class="card-title"><?php echo $row['price'];?></h6>
					<p class="card-text"><?php echo $row['details'];?></p>
					
					 <a href="details.php?pkgid=<?php echo $row['id'];?>" class="view">order this</a>
					 <div class="ban-bottom">
				<div class="bnr-right">
 </form>
<?php
}
}  
else
 {
 	echo "";
 }

?>
</section>

<?php



include("db_conn.php");
error_reporting(0);
session_start();

$query="SELECT * FROM food ";
$data=mysqli_query($connn,$query);
$total=mysqli_num_rows($data)>0;
if($total)
{
	while ($row =mysqli_fetch_assoc($data)) {

		?>

		


		

		<div   class="col-md-3 mt-3   ">


			<div class="card">
				<div class="card-body">

					<div class="ddd">



			

				<img src=" <?php echo $row['img']; ?>" class="rounded mx-auto d-block"   height="200px" width='200px' alt="img">
					
				<h4 class="card-title"><?php echo $row['name'];?></h4>
				
				
					
					<h3 class="card-title"><?php echo $row['type'];?></h3>
					<h6 class="card-title"><?php echo $row['price'];?></h6>
					<p class="card-text"><?php echo $row['details'];?></p>
					
					 <a href="details.php?pkgid=<?php echo $row['id'];?>" class="view">order this</a>
					 <div class="ban-bottom">
				<div class="bnr-right">
				
				
			</div>
			</div>
					

					

				

			</div>
		</div>
	</div>

</div>

<?php  
		
		# code...
	}
}
 else
 {
 	
 }
 ?>
 </form>


