<?php
require('admh.php')
?>
<?php
include("db_conn.php");
error_reporting(0);
$query="SELECT * FROM food ";
$data=mysqli_query($connn,$query);
$total=mysqli_num_rows($data);
$result=mysqli_fetch_assoc($data);
 
 if($total != 0)
 {

 ?>
<style type="text/css">
   form{
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
    table{
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
    }
    tr,td,th{
      font-family: "Comic Sans MS", cursive, sans-serif;

    }
 </style>
 <table>
 	<h1>list of food</h1>
 	
 	
 	
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<body>
 	
<table class="table table-hover">
 	<tr>
 		<th>id</th>
 		<th>pic</th>
 		<th>name</th>
 		<th>price</th>
 		<th colspan="2"> operations</th>
 	</tr>
 
 <?php 
 while ($result=mysqli_fetch_assoc($data))
  {
 	echo "<tr>
 		<td>".$result['id']."</td>
 		<td><a href='$result[img]'><img src='".$result['img']."' height='100' width='100'/><a/></td>
 		<td>".$result['name']."</td>
 		<td>".$result['price']."</td>
 		<td> <a href='updatep.php?ii=$result[id]&iii=$result[name]&iiii=$result[price]'>edit</a></td>
 		<td> <a href='deletep.php?ii=$result[id]&iii=$result[name]&iiii=$result[price]'>edit</a></td>
 		
 	</tr>";
}
}
 else
 {
 	echo " lol";
 }
  ?>
</table></body>
