<?php


include('adlog.php'); // Includes Login Script
if(isset($_SESSION['ad_user'])){
	session_start();
header("location: admin.php"); // Redirecting To Profile Page
}
?>

<!DOCTYPE html>
<html>
<head>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

<title>Login </title>
<style >

	
	body {
     background-image:url(f/admin.jpg);
   background-size: 1400px;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}
form {
	 width: 500px;
  border: 2px solid #ccc;
  padding: 30px;
  background-color: #FFFFFF;
  border-radius: 15px;
   
}



</style>




</head>
<body >
	

  
  		
<form  action="" method="post">

<h2>admin Form</h2>

<label>UserName :</label>
<input type="text" class="form-control" name="username" value="" required="" placeholder="Enter name"><br>
<label>Password :</label>
 <input type="password"   class="form-control"  name="password" value="" required="" placeholder="***********"><br>
<input name="submit" class="form-control"  type="submit" value=" Login ">

<span><?php echo $error; ?></span>
</form>

</body>


</html>