

<?php

include("db_conn.php");
include('login.php');
session_start();
error_reporting(0);
$user= $_SESSION['login_user'];
$query="SELECT * FROM orders  where name='$user' ";
$data=mysqli_query($connn,$query);
$total=mysqli_num_rows($data);
$result=mysqli_fetch_assoc($data);

 
 if($total != 0)
 {

 ?>
<form action="" method="POST">
 <table>
 	<h1>your orders</h1>
 
<style type="text/css">
	h1{
  
      font-family: "Comic Sans MS", cursive, sans-serif;
  }
  table {
      background-color: #ff4f58ff;
      font-family: "Comic Sans MS", cursive, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

 td,  th {

  border: 1px solid #ddd;
  padding: 8px;
}

 tr:nth-child(even){background-color: #f2f2f2;}

 tr:hover {background-color: #ddd;}

 th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000000;
  color: white;
}
</style>
 	

 	<tr>
 		<th>id</th>
 		
 		<th>name</th>
 		<th>order name</th>

 		<th>quantity</th>
 		<th>total</th>
 		<th colspan="1"> operations</th>
 	</tr>
 
 <?php 
 $idd=$_POST['result["id"]'];
 while ($result=mysqli_fetch_assoc($data))
  {
 	echo "<tr>
    <td>".$result['id']."</td>
    <td>".$result['name']."</td>
 		<td>".$result['oname']."</td>
      <td>".$result['quantity']."</td>
        <td>".$result['total']."</td>
 		
 		
 			
 		<td> <a href='deletep.php?icc=$result[id]&iii=$result[name]&ty=$result[type]&iiii=$result[price]&det=$result[details]'>delete</a></td>
 		
 	</tr>";
}
}
 else
 {
 	echo " lol";
 }
  ?>
</table>
</form>
 



 