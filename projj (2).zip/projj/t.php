
<?php  
include('login.php');
session_start();
if(isset($POST['checkout'])){
  $amount=$POST['checkout'];
}
?>
<?php
include("db_conn.php");

error_reporting(0);

?>

<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="jquery.min.js"></script>
  <style type="text/css">
    body{
      background-color: #000000;
       color: black;
    }
    div{
     
    }
    form{
    
      font-family: "Comic Sans MS", cursive, sans-serif;
       color: black;
    }
    .form1{

      position: relative;
      left:600px;
      bottom: 400px;
      font-family: "Comic Sans MS", cursive, sans-serif;
      color: black;




    }
    .but{
    
        border: none;
  color: white;
  padding: 10px 29px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  font-family: "Comic Sans MS", cursive, sans-serif;

    }
    .div {
  position: relative;
  width: 400px;
  height: 200px;
  border: 3px solid red;
  font-family: "Comic Sans MS", cursive, sans-serif;
}
.w3-panel {
    background-color: #000000;
      font-family: "Comic Sans MS", cursive, sans-serif;
}

  </style>

  <title></title>
</head>
<body>
   <div class="w3-panel w3-green w3-round-xlarge">
     <h1> <?php echo $_SESSION['login_user'];  ?>'s ORDER</h1></div>
      <div class="panel-body">
        <?php
        $r= rand(100,1000)
          ?>
 <div class="w3-panel w3-red w3-round-xlarge">
        <?php 
$pid=intval($_GET['pkgid']);

$query="SELECT * FROM food where id=$pid";
$data=mysqli_query($connn,$query);


$total=mysqli_num_rows($data)>0;





if($total)
  
{

  while ($row =mysqli_fetch_assoc($data)) {

    ?>
   
    <form action="" method="POST" >
    
    <div class="col-md-3 mt-3">
      <div class="card">
        <div class="card-body">
    <input type="text" value="<?php echo $r; ?>" hidden="" name="i">

        <img src=" <?php echo $row['img']; ?>" class height="200px" width='200px' alt="img">
          <h4  class="card-title"> <input type="text" name= "a" value= <?php echo $row['name'];?> >
        
        
          
          <h3 class="card-title"> Type: <?php echo $row['type'];?></h3></label> 
          <h3 class="card-title"> Price:Rs <?php echo $row['price'];?></h3></label> 
          <h4 class="card-text"> Details:<?php echo $row['details'];?></h4></label> 
         

         


          <div class="form1">
 <form  method="post">  
  <h1 > YOUR BILL  </label></h1>
price: 
<input  type="text"  name= ""class="form-control" id="number" value="<?php echo $row['price'];?>  " readonly><br><br>  
Enter the quantiy:  

<input  type="text" name="b" class="form-control"  id="number"  /><br>
<br>  
<label>your total will be:</label> <input type="text"  name="d" id="total" 
           value="" >
<input type="submit"   value ="submit" name="submit" >
<br>
<input type="submit" value="CheckOut"  form="myform" >



  


  
</form>  




          

          
  
 

        

      </div>
    </div>
  </div>



<?php  
    
    
  }
}
 else
 {
  echo "error";
 }
 ?>

 


</body>
<section>
  

    <?php
 if (isset($_POST['CheckOut'])) {
  //echo $row['type'];


 

if ($data) {
  echo "deleted";
}

else{
  echo "failed";

}

    
}
else
{
   echo '';
}
  
 

 

?>

<form id="myform" method="post" action="PaytmKit/pgRedirect.php">

    <table border="1">
      <tbody>
        <tr>
          <th hidden="">S.No</th>
          <th hidden="">Label</th>
          <th hidden="">Value</th>
        </tr>
        <tr>
          <td hidden="">1</td>
          <td><label hidden="">ORDER_ID::* </label></td>
          <td><input hidden=""id="ORDER_ID" tabindex="1" maxlength="20" size="20"
            name="ORDER_ID" autocomplete="off"
            value="<?php echo  "ORDS" . rand(10000,99999999)?>">
          </td>
        </tr>
        <tr>
          <td hidden="">2</td>
          <td><label hidden="">CUSTID ::*</label></td>
          <td><input hidden=""id="CUST_ID" tabindex="2" maxlength="12" size="12" name="CUST_ID" autocomplete="off" value="CUST001"></td>
        </tr>
        <tr>
          <td hidden="">3</td>
          <td hidden=""><label>INDUSTRY_TYPE_ID ::*</label></td>
          <td><input hidden=""id="INDUSTRY_TYPE_ID" tabindex="4" maxlength="12" size="12" name="INDUSTRY_TYPE_ID" autocomplete="off" value="Retail"></td>
        </tr>
        <tr >
          <td hidden="">4</td>
          <td hidden=""><label>Channel ::*</label></td>
          <td hidden=""><input id="CHANNEL_ID" tabindex="4" maxlength="12"
            size="12" name="CHANNEL_ID" autocomplete="off" value="WEB">
          </td>
        </tr>
        <tr>
          <td >5</td>
       <label  class="form-group"> Total amount*</label></td>
       <input id="total"  title="TXN_AMOUNT"  class="form1"  tabindex="10"
            type="text" name="TXN_AMOUNT"
            value="<?php echo $_POST['d']; ?>">
          </td >
           
          </td >
        </tr>
        <tr hidden="">
          <td hidden=""></td>
          <td hidden=""></td><br>
          <br hidden="">
           
           
          <input  value="CheckOut" type="submit"   onclick="">
          <?php 
if (isset($_POST['submit'])) {
  $i=$_POST['i'];
  $a=$_SESSION['login_user'];
  $b=$_POST['a'];
  $c=$_POST['b'];
  $d=$_POST['d'];


  
  
  if ( $i!=''&& $a!=''&& $b!=''&& $c!=''&& $d!='' ) 
{
  
  $conn = mysqli_connect("localhost", "root", "", "proj");
  $queryy ="INSERT INTO  orders VALUES ('$i', '$a', '$b', '$c', '$d')";
$data= mysqli_query($conn , $queryy);



if ($data) {
  echo "success";

}
}
else{
  echo "all fiels are required";

}
}


 ?>
      
</section>
<script>
  $('.form-control').keyup(function() {
     var sum = 1;
    $('.form-control').each(function() {
        sum *= Number($(this).val());
    });
    $('#total').val(sum);
     $('#totall').val(sum);
     
});
</script></html>






  


      </div>
    </div>

