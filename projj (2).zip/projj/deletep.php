<?php

include("db_conn.php");
$id=$_GET['icc'];
$query="DELETE FROM FOOD WHERE id='$id'";
$data= mysqli_query($connn , $query);

 

if ($data) {
	header('Refresh: 1; url=viewp.php');
}

else{
	echo "failed";

}
 ?>