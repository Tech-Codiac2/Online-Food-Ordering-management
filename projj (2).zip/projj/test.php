<?php
  $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   
   $connn = mysqli_connect($dbhost, $dbuser, $dbpass);
   
   if(! $connn ) {
      die('Could not connect: ' . mysqli_error());
   }
   
   $sql = 'SELECT id , name,price FROM prod';
   mysqli_select_db('proj');
   $retval = mysqli_query( $sql, $connn );
   
   if(! $retval ) {
      die('Could not get data: ' . mysqli_error());
   }
   
   while($row = mysqli_fetch_array($retval, MYSQL_ASSOC)) {
      echo "EMP ID :{$row['id']}  <br> ".
         "EMP NAME : {$row['name']} <br> ".
         "EMP SALARY : {$row['price']} <br> ".
         "--------------------------------<br>";
   }
   
   echo "Fetched data successfully\n";
   
   mysqli_close($connn);
?>